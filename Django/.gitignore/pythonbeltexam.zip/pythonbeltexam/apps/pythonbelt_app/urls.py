from django.conf.urls import url, include
from django.contrib import admin
from . import views

urlpatterns = [     
    #name of <form acton= xxx> goes in first place. ( after r'^ ). 
    url(r'^$', views.index, name = 'index'),
    url(r'^create$', views.create, name = "create"), #in views need to have a route with the same name
    url(r'^homepage$', views.homepage, name = 'homepage'), # routing, now routing to 'whatever' definition. make a new 'whatever' def on views page
    url(r'^login$', views.login, name = 'login'),
    url(r'^logout$', views.logout, name = 'logout'),
    url(r'^add$', views.add, name = 'add'),
    url(r'^remove$', views.remove, name = 'remove'),

    # url(r'^profile(?P<number>\d+)$', views.profile, name = 'profile')
]
